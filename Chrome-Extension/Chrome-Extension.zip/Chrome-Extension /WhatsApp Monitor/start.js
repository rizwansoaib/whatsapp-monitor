alert("You have WhatsApp Monitor Extension installed\nOpen Contacts Chat Window click extension then Start");

