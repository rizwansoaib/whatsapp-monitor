alert("You have WhatsApp Monitor Extension installed\nOpen Contacts Chat Window click extension then Start");


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>


