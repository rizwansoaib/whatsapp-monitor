# WhatsApp Monitor (Chrome Extension)

## Installation
This extension is not available in the Chrome store. You have to install it manually. That is an easy task, just following these steps:

1. Click 'clone or download' and choose to download the ZIP file	
2. Extract the folder from the ZIP file	
3. Open in url chrome://extensions/	in chrome browser
4. Enable developer mode at the top of the screen by clicking the slider	
5. Click 'load unpacked extension'	
6. **Go whatsapp-monitor then Chrome-Extension select Whatsapp Monitor folder**
7. A green Whatsapp icon should appear at the top of the screen
8. Open Whatsapp Web you will get popup 
9. Open Contact chat window and Click WhatsApp Monitor Extension icon 
10. Hit start button 

**Now When Your Contact become online then sound will play  in your Desktop**

